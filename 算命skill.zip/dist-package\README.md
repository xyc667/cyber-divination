# 赛博算卦 · 脚手架

一个开箱即用的「赛博算卦」React + TypeScript + Vite 脚手架。
内置 `cyber-divination` Trae skill，支持一键新增任意术数模块（奇门、周易、八字、梅花易数、六爻、射覆、紫微、太乙…）。

## 快速开始

```bash
# 1) 安装依赖（任选其一）
pnpm install        # 推荐
npm install
yarn install

# 2) 启动开发服务器
pnpm dev            # → http://localhost:5173

# 3) 打包生产版本
pnpm build
pnpm preview
```

> 需要 Node.js ≥ 18。

## 项目结构

```
.
├── public/                              # 静态资源
├── src/
│   ├── components/layout/Header.tsx     # 顶部导航 + 主题切换
│   ├── pages/
│   │   ├── HomePage.tsx                 # 首页
│   │   ├── DemoPage.tsx                 # 示范·起卦（用时间起卦的最简示例）
│   │   └── HistoryPage.tsx              # 历史占卜记录
│   ├── utils/demoCalculator.ts          # 示范计算器（纯函数）
│   ├── store/divinationStore.ts         # zustand 全局状态（带 localStorage 持久化）
│   ├── hooks/useTheme.ts                # 主题切换 hook
│   ├── lib/utils.ts                     # cn() / 日期格式化等工具
│   ├── App.tsx                          # 路由
│   ├── main.tsx
│   └── index.css                        # Tailwind + 古风主题
├── .trae/
│   └── skills/cyber-divination/         # ← 内置 Trae skill
│       ├── SKILL.md                     # AI 触发指令
│       ├── tools/add-divination-module.mjs   # 脚手架 CLI
│       ├── templates/                   # 页面/计算器模板
│       └── scripts/                     # 一键启动脚本 (sh / bat / ps1)
├── index.html
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── vite.config.ts
```

## 一键新增术数模块

```bash
pnpm add-module <kebab-name> "<中文标题>" <path-segment>

# 示例
pnpm add-module taiyi "太乙神数" /taiyi
pnpm add-module ziwei "紫微斗数" /ziwei
pnpm add-module qimen "奇门遁甲" /qimen
```

会自动完成：

1. 在 `src/utils/<kebab>Calculator.ts` 生成纯函数计算器骨架
2. 在 `src/pages/<Pascal>Page.tsx` 生成带表单 + 结果展示的页面
3. 在 `src/App.tsx` 注册新路由
4. 在首页 features 中追加一张卡片

然后你只需在 `<Kebab>Calculator.ts` 里实现真正的算法即可。

## 古风主题

在 `tailwind.config.js` 中定义了 4 个自定义色：

- `ancient-red`  `#8B0000`  （主色调：朱砂红）
- `ancient-orange` `#D2691E` （赭石）
- `ancient-gold` `#DAA520` （金）
- `ancient-brown` `#5D4037` （深褐）

CSS 类 `.ancient-card` 和 `.ancient-title` 已封装好卡片与标题渐变样式，可直接复用。

## 与 Trae AI 协作

本项目内置 `.trae/skills/cyber-divination/`。在 Trae IDE 中打开本项目后，对 AI 说：

- "启动赛博算卦"
- "加一个紫微斗数模块"
- "把项目打包"
- "解释一下示范起卦的算法"

AI 会自动调用本 skill 完成对应操作。

## 许可

MIT